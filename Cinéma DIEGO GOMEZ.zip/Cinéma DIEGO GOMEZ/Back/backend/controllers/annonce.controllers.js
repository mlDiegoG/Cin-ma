
const {Search, Genre, Random} = require('../models/annonce.model');
const { searchMovies, getMovieGenres, getMovieGenresFr, randomMovies} = require('../dbapi/api');

const searchMoviesController = async (req, res) => {
    try {
      const { query, include_adult, language, primary_release_year, page, region, year } = req.query;
  
      // Enregistrez les paramètres de recherche dans la base de données
      const searchRecord = new Search({
        query,
        include_adult: include_adult === 'true',
        language,
        primary_release_year,
        page: parseInt(page) || 1,
        region,
        year,
      });
      const savedSearch = await searchRecord.save();
  
      // Appelez l'API TMDb avec les paramètres de recherche
      const response = await searchMovies({
        query,
        include_adult: include_adult === 'true',
        language,
        primary_release_year,
        page: parseInt(page) || 1,
        region,
        year,
      });
  
      // Vérifiez si la propriété 'results' est présente dans la réponse
      const results = response.results || [];
  
      // Vous pouvez effectuer d'autres traitements ici si nécessaire
  
      // Envoyez les résultats au client
      res.json({
        searchRecord: savedSearch,
        results,
        page: response.page,
        total_pages: response.total_pages,
        total_results: response.total_results,
      });
    } catch (error) {
      console.error('Erreur lors de la recherche:', error);
      res.status(500).send('Erreur lors de la recherche');
    }
  };


  const searchGenreFr = async (req, res) => {
    try {
        // Récupérer tous les genres existants
        const genres = await getMovieGenres();

        res.json({ genres });
    } catch (error) {
        console.error(error);
        res.status(500).send('Erreur lors de la récupération des genres');
    }
};


const searchGenre = async (req, res) => {
    try {
      const { language } = req.query;
  
      // Assurez-vous que la langue est fournie
      if (!language) {
        return res.status(400).json({ error: 'La langue est requise dans les paramètres de la requête.' });
      }
  
      // Récupérer tous les genres existants pour la langue spécifiée
      const options = {
        method: 'GET',
        headers: {
          accept: 'application/json',
          Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3YTBkNTU1MzYwYzQyM2JjODVkMjdjMmY1YzA5NzkwNiIsInN1YiI6IjY1ZGIwZjcxYTI0YzUwMDE4NjEwNTAxNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.rr63d3nJKfRAwiXk7wN3LsG3zzdXMh2kHQJpk57FUTE'
        }
      };
  
      const response = await fetch(`https://api.themoviedb.org/3/genre/movie/list?language=${language}`, options);
  
      if (!response.ok) {
        throw new Error(`Erreur lors de la récupération des genres. Status: ${response.status}`);
      }
  
      const result = await response.json();
      const genres = result.genres.map(genre => ({
        id: genre.id,
        name: genre.name
      }));
  
      res.json({ genres });
    } catch (error) {
      console.error(error);
      res.status(500).send('Erreur lors de la récupération des genres');
    }
  };


// Contrôleur pour ajouter un film visionné avec note et commentaire
const random = async (req, res) => {
    try {
        const { genreId } = req.params; // Récupérez l'ID du genre depuis les paramètres de la requête
    
        const options = {
          method: 'GET',
          headers: {
            accept: 'application/json',
            Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzYTA3N2M4Yjc5ZDkxMDU4YzhmZWJjOTczNDBhOGDQ2YSIsInN1YiI6IjY1YzBmOTZkMDMxZGViMDE4M2YzNWFlOCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.HSF996KtRm7Ne1yRhDPrJ3gQw0WSM60xO4ITWRD_AiY'
          }
        };
    
        // Récupérez la liste des films pour un genre spécifique
        const moviesResponse = await fetch(`https://api.themoviedb.org/3/discover/movie?with_genres=${genre}&language=fr`, options);
        if (!moviesResponse.ok) {
          throw new Error(`HTTP error! Status: ${moviesResponse.status}`);
        }
    
        const moviesData = await moviesResponse.json();
        const movies = moviesData.results;
    
        // Choisissez un film aléatoire parmi la liste
        const randomMovie = movies[Math.floor(Math.random() * movies.length)];
        
        // Envoyez le film aléatoire en réponse
        res.json({ randomMovie });
      } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Erreur' });
      }
    };
  
  module.exports = {
    searchMoviesController,
    searchGenre,
    random,
    searchGenreFr,
  }; 




























// const annonceModel = require('../models/annonce.model');
// const AnnonceModel = require('../models/annonce.model');

// // On va exporter une méthode liée aux annonces qu'on pourra réutiliser par la suite
// // Sans faire appel à l'ensemble du controlleur
// module.exports.getAnnonces = async (req, res) => {
//      // pour que le Await fonctionne  écrire le async dans le routeur
//     const {price, text, author} = req.query;

//     let filter = {}
//     if(!isNaN(price)){
//         filter.price = {$gte: price};
//     }
//         //filter.title = new RegExp(req.query.title);
//     if(author){
//         filter.author = new RegExp('^' + author, 'i');
//     }
//     if(text){
//         filter.$or = [
//             {title: new RegExp(text, 'i')},
//             {description: new RegExp(text, 'i')}

//         ]
//     }
//     const annonces = await AnnonceModel.find(filter);
//     let data= {};

//     data.annonces = annonces;
//     data.message = "Récupération des données";
//     res.status( 200).json(data);
// }


// module.exports.postAnnonces = async (req, res) => {
//     const annonce = new AnnonceModel({
//            ...req.body
//     })
//     annonce.save()
//     .then(() => res.json({message: "Annonce crééer avec succès"}))
//     .catch(() => res.json({message: "Erreur avec la création des annonces"}))
// }

// module.exports.deleteAnnonces = async (req, res) => {
//     const id = req.params.id;
//     const annonceSupprimer = await AnnonceModel.findByIdAndDelete(id);

//     let response = {
//         status: 200,
//         message : 'Annonce Supprimée'
//     }
//     if(!annonceSupprimer){
//         response.status = 404
//         response.message = 'Aucune annonce trouvée'
//     }
//     res.status(response.status).json({'message': response.message})
// }

// module.exports.patchAnnonces = async (req, res) => {

//     try {
//         const annonceId = req.params.id; // Supposons que l'ID de l'annonce soit dans les paramètres de la requête
//         const updateFields = req.body; // Supposons que les champs à mettre à jour soient dans le corps de la requête

//         // Utilisez la méthode findOneAndUpdate pour mettre à jour l'annonce par son ID
//         const updatedAnnonce = await annonceModel.findOneAndUpdate(
//             { _id: annonceId },
//             updateFields,
//             { new: true }) // Pour renvoyer la version mise à jour de l'annonce
//         ;
//         if (!updatedAnnonce) {
//             return res.status(404).json({ message: 'Annonce non trouvée' });
//         }
//         res.json({ message: 'Annonce modifiée', annonce: updatedAnnonce });
//         // Envoyez la version mise à jour de l'annonce en tant que réponse
//         res.json(updatedAnnonce);
//     } catch (error) {
//         console.error(error);
//         res.status(200).json({ message: 'Erreur serveur lors de la mise à jour de l\'annonce' });
//     }
// }

// // faire un get pour une seul annonce

// module.exports.getRandomAnnonce = async (req, res) => {
//     try {
//         const { price, text, author } = req.query;

//         let filter = {};
//         if (!isNaN(price)) {
//             filter.price = { $gte: price };
//         }
//         if (author) {
//             filter.author = new RegExp('^' + author, 'i');
//         }
//         if (text) {
//             filter.$or = [
//                 { title: new RegExp(text, 'i') },
//                 { description: new RegExp(text, 'i') }
//             ];
//         }

//         const count = await AnnonceModel.countDocuments(filter);

//         // Générez un nombre aléatoire entre 0 et le nombre total d'annonces
//         const randomIndex = Math.floor(Math.random() * count);

//         // Utilisez l'agrégation avec la fonction $sample pour récupérer une annonce aléatoire
//         const randomAnnonce = await AnnonceModel.aggregate([
//             { $match: filter },
//             { $sample: { size: 1 } }
//         ]);

//         if (!randomAnnonce || randomAnnonce.length === 0) {
//             return res.status(404).json({ message: 'Aucune annonce trouvée' });
//         }

//         res.json(randomAnnonce[0]);
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ message: 'Erreur' });
//     }
// }
