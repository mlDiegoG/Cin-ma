// Pour lance le terminal: npx nodemon server
// utliser ma librairie express
const express = require('express');
const path = require('path');
// Je dédie ke port d'écoute
const port = 3000;
// Je créé mon instance express
const app = express();

// Récupérer la connexion à la base de données
const connectDB = require('./config/db.js');

// Permet à mon app d'utiliser et d'interpréter le json et les formulaire d'URL encodé
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.use((req,res,next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-type');
    next();
})
//Création de notre première route
app.get('/', (request, response) => {
    response.sendFile(path.resolve('./fronted/index.html'));
});

app.get('/prenom/:prenom', (req, res) =>{
    res.send(`Bonjour ${req.params.prenom}`)
})

// Utliser les routeurs
app.use('/api', require('./routes/api/annonce.route.js'));

//lancer ke serveur
app.listen(port, ()=>{
    console.log(`Serveur lancé sur le port ${port}`);
})

