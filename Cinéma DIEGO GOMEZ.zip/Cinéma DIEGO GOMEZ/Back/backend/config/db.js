const mongoose = require('mongoose');

const connectDB= mongoose.connect("mongodb+srv://Diego:Diego2001@cluster0.efotvb5.mongodb.net/DC2")
    .then(() => console.log('Connexion à MongoDB réussi'))
    .catch((err) => console.log('Connexion à MongoDB échouée',err));

module.exports= connectDB;


// npx nodemon serveur

