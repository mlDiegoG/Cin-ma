// api.js

// Liste de film
const searchMovies = async (queryParams) => {
  const { query} = queryParams; // Extrayez la valeur de la requête depuis queryParams

  const options = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzYTA3N2M4Yjc5ZDkxMDU4YzhmZWJjOTczNDBhOGQ2YSIsInN1YiI6IjY1YzBmOTZkMDMxZGViMDE4M2YzNWFlOCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.HSF996KtRm7Ne1yRhDPrJ3gQw0WSM60xO4ITWRD_AiY'
    }
  };

  try {
    const response = await fetch(`https://api.themoviedb.org/3/search/movie?query=${query}&include_adult=false`, options);
    const data = await response.json();
    console.log(data);
    return data;
  } catch (error) {
    console.error(error);
    throw error;
  }
};



// Listé par genre
const getMovieGenres = async (genre) => {
  const options = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3YTBkNTU1MzYwYzQyM2JjODVkMjdjMmY1YzA5NzkwNiIsInN1YiI6IjY1ZGIwZjcxYTI0YzUwMDE4NjEwNTAxNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.rr63d3nJKfRAwiXk7wN3LsG3zzdXMh2kHQJpk57FUTE'
    }
  };
  
  fetch('https://api.themoviedb.org/3/genre/movie/list?language=fr', options)
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(response => {
      const genres = response.genres.map(genre => ({
        id: genre.id,
        name: genre.name
      }));
      console.log({ genres });
    })
    .catch(err => console.error(err));
};


const getMovieGenresFr = async () => {
  try {
   const options = {
  method: 'GET',
  headers: {
    accept: 'application/json',
    Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3YTBkNTU1MzYwYzQyM2JjODVkMjdjMmY1YzA5NzkwNiIsInN1YiI6IjY1ZGIwZjcxYTI0YzUwMDE4NjEwNTAxNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.rr63d3nJKfRAwiXk7wN3LsG3zzdXMh2kHQJpk57FUTE'
  }
};

fetch('https://api.themoviedb.org/3/genre/movie/list?language=fr', options)
  .then(response => response.json())
  .then(response => console.log(response))
  .catch(err => console.error(err));
  } catch (error) {
    throw error;
  }
};

// Liste de film random
// Fonction pour obtenir un film aléatoire
const randomMovies = async () => {
  const options = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      Authorization: `Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3YTBkNTU1MzYwYzQyM2JjODVkMjdjMmY1YzA5NzkwNiIsInN1YiI6IjY1ZGIwZjcxYTI0YzUwMDE4NjEwNTAxNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.rr63d3nJKfRAwiXk7wN3LsG3zzdXMh2kHQJpk57FUTE`
    }
  };

  const response = await fetch('https://api.themoviedb.org/3/search/movie?include_adult=false&language=en-US&page=1', options);
  const data = await response.json();

  // Choisissez un film aléatoire parmi les résultats
  const randomIndex = Math.floor(Math.random() * data.results.length);
  const randomMovie = data.results[randomIndex];

  return randomMovie;
};


module.exports = { searchMovies, getMovieGenres, getMovieGenresFr, randomMovies};
