// models/search.model.js
const mongoose = require('mongoose');

const searchSchema = new mongoose.Schema({
  query: {
    type: String,
    required: true,
  },
  include_adult: {
    type: Boolean,
    default: false,
  },
  language: {
    type: String,
    default: 'en-US',
  },
  primary_release_year: {
    type: String,
  },
  page: {
    type: Number,
    default: 1,
  },
  region: {
    type: String,
  },
  year: {
    type: String,
  },
});

const genreSchema = new mongoose.Schema({
    language: {
      type: String,
      required: true,
    },
});


const randomSchema = new mongoose.Schema({
    id: {
      type: Number,
      required: true,
    },
    include_adult: {
      type: Boolean,
      default: false,
    },
    language: {
      type: String,
      default: 'en-US',
    },
    primary_release_year: {
      type: String,
    },
    page: {
      type: Number,
      default: 1,
    },
    region: {
      type: String,
    },
    year: {
      type: String,
    },
  });
  
  
const Genre = mongoose.model('Genre', genreSchema);
const Search = mongoose.model('Search', searchSchema);
const Random = mongoose.model('Random', randomSchema);

module.exports = {Search, Genre, Random};



















// const annonceSchema = mongoose.Schema(
//     {
//         title: {
//             type : String,
//             required : true
//         },
//         description: {
//             type : String,
//             required : true
//         },
//         author: {
//             type : String,
//             required : true
//         },
//         price: {
//             type : Number,
//             required : true
//         },
//     }
// )
// module.exports = mongoose.model('Annonces', annonceSchema);