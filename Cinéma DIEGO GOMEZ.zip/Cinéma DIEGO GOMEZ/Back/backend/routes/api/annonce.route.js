const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const { searchMoviesController, searchGenre, addWatchedMovie, random, getWatchedMovies, searchGenreFr, getTopGenresAndMovies, getStatistics, getRandomMovie } = require('../../controllers/annonce.controllers');

const router = express.Router();

// Utilisation de http-proxy-middleware pour rediriger les requêtes vers l'API TMDb
router.use('/api/search', createProxyMiddleware({
  target: 'https://api.themoviedb.org/3',
  changeOrigin: true,
  pathRewrite: {
    '^/api/search': '/search/movie',
  },
  onProxyReq: (proxyReq, req, res) => {
    // Ajoutez votre clé d'API TMDb à chaque requête sortante
    proxyReq.setHeader('Authorization', 'Bearer 7a0d555360c423bc85d27c2f5c097906');
  },
}));

router.get('/search', searchMoviesController);
router.get('/genre', searchGenre);
router.get('/genrefr', searchGenreFr);
router.get('/random', random);

module.exports = router;










//Constante permettant de récupérer toutes les métodes du controlleur.
// const {getAnnonces, postAnnonces, deleteAnnonces, patchAnnonces, getRandomAnnonce} = require('../../controllers/annonce.controllers')

// //Création d'une route pour afficher les annonces
// router.get('/annonce', getAnnonces);
              
// router.post('/annonce', postAnnonces);
    
// router.delete('/annonce/:id', deleteAnnonces);

// router.patch('/annonce', patchAnnonces); 

// router.patch('/annonce/:id', patchAnnonces)

// router.get('/annonce/random', getRandomAnnonce)

// router.get('/test', (req,res) => {
//     res.status(200).json({
//         nom: 'Gomez',
//         prénom: 'Diego',
//         age: 22
//     });
// })
// module.exports = router;