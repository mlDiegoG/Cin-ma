<script>
    import Recherche from "./lib/Recherche.svelte"
</script>


<script>
    import { onMount } from 'svelte';
    import { searchMovies } from './lib/api';
  
    let searchResults = [];
  
    const performSearch = async (query) => {
      searchResults = await searchMovies(query);
    };
  
    onMount(() => {
      // Exemple d'utilisation lors de l'initialisation du composant
      performSearch(`${query}`);
    });
  </script>
  
  <input type="text" on:input={e => performSearch(e.target.value)} placeholder="Search...">
  
  <!-- Affichez les résultats de la recherche ici -->
  {#if searchResults.length > 0}
    <ul>
      {#each searchResults as result (result.id)}
        <li>{result.title}</li>
      {/each}
    </ul>
  {/if}