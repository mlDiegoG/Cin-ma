<script>
import { onMount } from 'svelte';
import {searchMoviesController} from '../../../dbapi/api';

</script>

